public class Cleaner extends CoordinatedAsset{
    public Cleaner(String n, String s) {
        setName(n);
        setSecrete(s);
    }

    @Override
    public void statusChange() {
        System.out.println(getName()+"status update");

    }
}
