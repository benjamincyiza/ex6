public class Mole extends CoordinatedAsset{

    public Mole(String n, String s) {
        setName(n);
        setSecrete(s);
    }
    public Mole(String n, String s, StaticMediator staticMediator) {
        setName(n);
        setSecrete(s);
        setStaticMediator(staticMediator);
    }

    @Override
    public void statusChange() {
        System.out.println(getName()+" status update");
        if(getName().equals("m1 ")){
            getStaticMediator().m1StatusChange();
        }
        if (getName().equals("m2 ")) {
            getStaticMediator().m2StatusChange();
        }
        if (getName().equals("m3 ")) {
            getStaticMediator().m3StatusChange();
        }
    }
}
