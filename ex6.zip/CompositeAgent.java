import java.util.ArrayList;

public class CompositeAgent {
    private ArrayList<CoordinatedAsset> coordinatedAssets;

    public CompositeAgent(ArrayList<CoordinatedAsset> c) {
        coordinatedAssets=c;
    }

    public ArrayList<CoordinatedAsset> getCoordinatedAssets() {
        return coordinatedAssets;
    }

    public void statusChange() {
        System.out.println("team status changed");
        for (CoordinatedAsset cordi: coordinatedAssets){
            cordi.statusChange();
        }
    }

    @Override
    public String toString() {
        String out="team: \n";
        for (CoordinatedAsset cordi: coordinatedAssets){
            out=out+cordi.toString()+"\n";
        }
        return out;
    }
}
