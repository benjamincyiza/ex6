public class Spy extends CoordinatedAsset{

    private Integer clearance;

    public Spy(String n, String s, int c, StaticMediator stat) {
        setName(n);
        setSecrete(s);
        clearance=c;
        setStaticMediator(stat);
    }

    // getters function
    public Integer getClearance() {
        return clearance;
    }

    //setters


    public void setClearance(Integer clearance) {
        this.clearance = clearance;
    }

    @Override
    public String toString() {
        return super.toString()+" my clearance "+ clearance;
    }

    @Override
    public void statusChange() {
        System.out.println(getName()+" status update ");
        if(getName().equals("spy1 ")){
            getStaticMediator().s1StatusChange();
        }
        else if (getName().equals("spy2 ")){
            getStaticMediator().s2StatusChange();
        }
        else if(getName().equals("spy3 ")){

            getStaticMediator().s3StatusChange();
        }

        else if(getName().equals("spy4 ")){

            getStaticMediator().s4StatusChange();
        }

    }
}
