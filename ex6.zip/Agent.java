public class Agent extends CoordinatedAsset{

    public Agent(String n, String s) {
        setName(n);
        setSecrete(s);
        setStaticMediator(null);
    }
    public Agent(String n, String s, StaticMediator staticM) {
        setName(n);
        setSecrete(s);
        setStaticMediator(staticM);
    }

    @Override
    public String toString() {
        return super.toString();
    }

    @Override
    public void statusChange() {
        System.out.println(getName()+" status update");
        if(getName().equals("a1 ")){
            getStaticMediator().a1StatusChange();
        }
        if(getName().equals("cleaner ")){
            getStaticMediator().c1StatusChange();
        }
        if (getName().equals("a2 ")) {
            getStaticMediator().a2StatusChange();
        }
        if(getName().equals("a3 ")){
            getStaticMediator().a3StatusChange();
        }
    }
}
