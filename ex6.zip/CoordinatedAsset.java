public abstract class CoordinatedAsset {
    private String name;
    private String secrete;
    private StaticMediator staticMediator;

    //getters methods
    public String getName() {
        return name;
    }
    public StaticMediator getStaticMediator() {
        return staticMediator;
    }

    public String getSecrete() {
        return secrete;
    }

    //setters method

    public void setName(String name) {
        this.name = name;
    }

    public void setSecrete(String secrete) {
        this.secrete = secrete;
    }

    public void setStaticMediator(StaticMediator staticMediator) {
        this.staticMediator = staticMediator;
    }

    @Override
    public String toString() {
        return name+" "+secrete;
    }

    public abstract void statusChange();
}
